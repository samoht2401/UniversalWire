package samoht2401.universalwire.system;

public interface IEnergyBuffer {
	public int getBufferSize();
}
