package samoht2401.universalwire.network;

public class PacketIDs {

	public final static int SYSTEM_UPDATE = 0;
}
